$(function() {
    var content_text = $('#content_text');
    var captcha = $('.re_captcha');


    content_text.blur(function() {
        if ($(this).val() == '') {
            $(this).val('请输入内容');
        }
    }).focus(function() {
        $(this).val('');
    });

    captcha.click(function() {
        var captcha = $(this).children();
        var currentSrc = captcha.attr('src');
        var src = currentSrc + "?r=" + Math.random();
        captcha.attr('src', src);
    })
});