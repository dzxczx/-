$(function() {
    var home_item   = $('.home'),
        show_item   = $('.show'),
        create_item = $('.create'),
        edit_item   = $('.edit'),
        delete_item = $('.delete');

    var home_content   = $('.home-content'),
        show_content   = $('.show-content'),
        create_content = $('.create-content'),
        edit_content   = $('.edit-content'),
        delete_content = $('.delete-content');

    var all = $('#all');


    all.click(function() {
           // $(':checkbox').attr('checked', 'true');
           // $('.edit-text').attr('disabled', 'true');
           // $('.cat-text').attr('disabled', 'true');
           // $(':checkbox').removeAttr('checked');
           // $('.edit-text').removeAttr('disabled');
           // $('.cat-text').removeAttr('disabled');
        alert('功能开发中....');
    });

    $('.delete_text').click(function(ev) {
        alert('功能开发中....');
    });

    $('.edit-text').click(function(ev) {
        alert('功能开发中....');
    });

    $('.cat-text').click(function(ev) {
        alert('功能开发中....');
    });

    $(document).click(function(e) {
        var target = $(e.target).attr('class');

        switch (target) {
            case getClassName(home_item):
                changeParentClass(home_item);
                displayContent(home_content);
                break;
            case getClassName(show_item):
                changeParentClass(show_item);
                displayContent(show_content);
                break;
            case getClassName(create_item):
                changeParentClass(create_item);
                displayContent(create_content);
                break;
            case getClassName(edit_item):
                changeParentClass(edit_item);
                displayContent(edit_content);
                break;
            case getClassName(delete_item):
                changeParentClass(delete_item);
                displayContent(delete_content);
                break;
        }
    });

    function getClassName($ele) {
        return $ele.attr('class');
    }

    function changeParentClass($ele) {
        $ele.parent().siblings().removeClass('active');
        $ele.parent().addClass('active');
    }

    function displayContent($ele) {
        $ele.siblings().css('display', 'none');
        $ele.css('display', 'block');
    }
})