/**
 * Created by Administrator on 2017/2/28.
 */
$(function() {
    $('#signupForm').validate({
        rules : {
            title : 'required',
            name : 'required',
            qqnum : {
                required : true,
                digits : true,
                minlength : 5,
                maxlength : 10,
            },
            content_text : 'required'
        },
        messages : {
            title : "标题不能为空",
            name : "姓名不能为空",
            qqnum : {
                required : 'qq必填',
                digits : '请输入数字',
                minlength : "你居然有低于5位的QQヽ(●-`Д´-)ノ",
                maxlength : "你的QQ这么长ヽ(=^･ω･^=)丿我们不要ʅ（´◔౪◔）ʃ"
            },
            content_text : "内容不能为空"
        }
    });

    $('#captcha').keyup(function() {
        var value = $(this).val();
        var currentUrl = location.href.substr(0,20);
        var url = currentUrl + 'Home/Index/checkVerify';

        $.ajax({
            type : 'post',
            url : url,
            data : {code : value},
            dataType : 'json',
            success : function(d) {
                if (d.status == 1) {
                    $('.danger').css('display', 'none');
                    $('.success').css('display', 'block');
                    $('.submit').attr('disabled',false);
                } else {
                    $('.success').css('display', 'none');
                    $('.danger').css('display', 'block');
                    $('.submit').attr('disabled', 'true');
                }
            },
            fail : function(e) {
                console.log(e);
            }
        })
    })
})