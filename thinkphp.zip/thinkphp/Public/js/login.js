$(function() {
    $('#loginForm').validate({
           rules : {
               username : 'required',
               password : 'required',
               captcha  : 'required'
           },

           messages : {
               username : '用户名不能为空！',
               password : '密码不能为空！',
               captcha  : '验证码不能为空！'
           }
       });

       $('.re_captcha').click(function() {
           var captcha = $(this).children();
           var currentSrc = captcha.attr('src');
           var src = currentSrc + "?r=" + Math.random();
           captcha.attr('src', src);
       })
})
