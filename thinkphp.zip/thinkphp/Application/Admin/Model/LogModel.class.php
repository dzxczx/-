<?php
    namespace Admin\Model;
    use Think\Model;

    class LogModel extends Model {
        protected $tableName = 'change_log';
    }