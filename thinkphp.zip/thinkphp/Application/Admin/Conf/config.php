<?php
    return array(
        'URL_PARAMS_BIND' => true,
    );