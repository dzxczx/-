<?php
    namespace Admin\Controller;
    use Think\Controller;

    class AdminController extends Controller {

        public function admin() {
            $this->check();
            $this->readData();
            $this->assign('name', session('username'));
            $this->display('admin');
        }

        public function login() {
            $this->display('login');

        }

        public function login_check($username, $password) {
            if (IS_POST) {
                $code = I('post.captcha');
                if ($this->checkVerify($code, 2)) {
                    $username = I('post.username');
                    $password = I('post.password');
                    if ($username != '' && $password != '') {
                        $user = M('message_user');
                        $condition['username'] = $username;
                        $condition['password'] = md5($password);
                        if ($result = $user->where($condition)->find()) {
                            $condition['id'] = $result.id;
                            $data['login_time'] = time();
                            $data['login_ip'] = get_client_ip();
                            $user->where($condition)->save($data);
                            session('username', $username);
                            session('admin', 'dz666');
                            $this->success('登录成功,正在跳转...', '/Admin/Admin/admin');
                        } else {
                            die('用户名或密码错误！');
                        }
                    } else {
                        die('用户名或密码不能为空！');
                    }
                } else {
                    die('验证码错误!');
                }
            } else {
                die('非法提交!');
            }
        }

        private function check() {
            if (! session('admin')) {
                $this->error('非法操作...', '/Admin/Admin/login');
                exit;
            }
        }

        private function write_log($actionName) {
            $log = D('Log');
            $data['user'] = session('username');
            $data['change_time'] = time();
            $data['change_ip'] = get_client_ip();
            $data['change_log'] = "$actionName";
            $log->add($data);
        }

        public function showVerify() {
            $manager = A('Common/Manager');
            $manager->showVerify(2);
        }

        private function checkVerify($code,$id) {
            $manager = A('Common/Manager');
            return $manager->checkVerify($code,2);
        }

        public function createData() {
            $manager = A('Common/Manager');
            if ($manager->createData()) {
                $this->write_log('create');
                $this->success('发表成功...', '/Admin/Admin/admin');
            } else {
                $this->error('发表失败...', '/Admin/Admin/admin');
            }
        }

        public function updateData() {
            $manager = A('Common/Manager');
            if ($manager->updateData()) {
                $this->write_log('update');
                $this->success('更新成功...', '/Admin/Admin/admin');
            } else {
                $this->error('更新失败...', '/Admin/Admin/admin');
            }
        }

        private function readData() {
            $manager = A('Common/Manager');
            $data = $manager->pageData(10);
            $this->assign('data', $data);
        }

        public function deleteData($id) {
            $manager = A('Common/Manager');
            if ($manager->deleteData($id)) {
                $this->write_log('delete');
                $this->success('删除成功...', '/Admin/Admin/admin');
            } else {
                $this->error('删除失败...', '/Admin/Admin/admin');
            }
        }
    }
