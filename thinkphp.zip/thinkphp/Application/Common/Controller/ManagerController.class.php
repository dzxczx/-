<?php
    namespace Common\Controller;
    use Think\Controller;
    use Think\Model;
    use Think\Verify;
    use Think\Page;

    class ManagerController extends Controller {

        public function createData() {
            $message = D('Message');
            if (! $message->create()) {
                die($message->getError());
            }
            $message_text = M('message_text');
            $data['content'] = I('post.content_text', '666');
            $message->add();
            $message_text->add($data);
            return true;
        }

        public function updateData() {
            $message = D('Message');
            if (! $message->create()) {
                die($message->getError());
            }
            $condition['content_id']  = $message->id;
            $data['content'] = I('post.content_text', '666');
            $message->save();
            $message_text = M('message_text');
            $message_text->where($condition)->save($data);
            return true;
        }


        public function deleteData($id) {
            if (IS_GET) {
                //$id = I('get.id');
                    is_numeric($id) ? false : die('id非法！');
                    $condition['id'] = $id;
                    $message = D('Message');
                    $message_text = M('message_text');
                    $condition2['content_id'] = $id;
                    $message->where($condition)->delete();
                    $message_text->where($condition2)->delete();
                    return true;
            } else if(IS_POST) {
                $id = I('post.id');
                $message = D('Message');
                $message_text = M('message_text');
                $result = explode(',', $id);
                $result_c = count($result);

                for ($i = 0; $i<$result_c; $i++) {
                    is_numeric($result[$i]) ? false : die('id非法！');
                    $condition['id'] = $result[$i];
                    $condition2['content_id'] = $result[$i];
                    $message->where($condition)->delete();
                    $message_text->where($condition2)->delete();
                }
                return true;
            }
        }

        public function showVerify($id) {
            $verify = new Verify();
            $verify->entry($id);
        }

        public function checkVerify($code, $id) {
            $verify = new Verify();
            return $verify->check($code,$id);
        }

        /**
         * @param $showNum int
         * @return array
        */
        public function pageData($showNum) {
            $return_data = array();
            $model = new Model();
            $query_count_sql = "select count(id) as c from message_info as mi,message_text as mt where mi.id = mt.content_id ";
            $query_count_r = $model->query($query_count_sql, true);
            $count = $query_count_r[0]['c'];
            $page = new Page($count, $showNum);
            $query_data_sql = "select * from message_info, message_text where message_info.id = message_text.content_id order by id desc limit $page->firstRow, $page->listRows";
            $query_data_r = $model->query($query_data_sql, true);
            $return_data['count'] = $count;
            $return_data['data'] = $query_data_r;
            $return_data['page'] = $page->show();
            return $return_data;

        }
    }