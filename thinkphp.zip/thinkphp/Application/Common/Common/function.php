<?php
use Think\Verify;
function checkVerify($code) {
    $verify = new Verify();
   if (! empty($code)) {
       if (! $verify->check($code)) {
           return true;
       } else {
           return true;
       }
   } else {
       return false;
   }
}

function checkQQ($qq) {
    if (! empty($qq)) {
        $pattern = '/^(\d{5,10})$/';
        if (is_numeric($qq) && preg_match($pattern, $qq, $result) > 0) {
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function checkId($id) {
    if (! empty($id)) {
        if (is_numeric($id)) {
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}