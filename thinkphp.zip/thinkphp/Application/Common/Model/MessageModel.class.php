<?php
    namespace Common\Model;
    use Think\Model;

    class MessageModel extends Model {
        protected $tableName = 'message_info';
        protected $_validate = array(
            array('id', 'checkId', 'id错误', 0, 'function'),
            array('title', 'require', '标题不能为空！'),
            array('name', 'require', '名称不能为空！'),
            array('qqnum', 'checkQQ', 'qq号输入错误！', 0, 'function'),
            array('content_text', 'require', '内容不能为空！'),
            array('captcha','checkVerify', '验证码错误', 1, 'function'),
        );
        protected $_auto = array(
            array('id', 'htmlspecialchars', 'function'),
            array('title', 'htmlspecialchars', 'function'),
            array('name', 'htmlspecialchars', 'function'),
            array('qqnum', 'htmlspecialchars', 'function'),
            array('create_time', 'time', 1, 'function'),
            array('create_ip', 'get_client_ip', 1, 'function'),
            array('update_time', 'time', 2, 'function'),
            array('update_ip', 'get_client_ip', 2, 'function')

        );
    }