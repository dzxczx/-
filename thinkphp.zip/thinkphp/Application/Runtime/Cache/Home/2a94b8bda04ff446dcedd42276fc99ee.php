<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Title</title>
    <link rel="stylesheet" href="/Public/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Public/css/form.css">
    <link rel="stylesheet" href="/Public/css/index.css">
    <link rel="stylesheet" href="/Public/css/article.css">
    <link rel="stylesheet" href="/Public/css/date_default.css">
    <link rel="stylesheet" href="/Public/css/date_main.css">
    <link rel="stylesheet" href="/Public/css/htmleaf-demo.css">
    <link rel="stylesheet" href="/Public/css/glowing.css">
    <script src="/Public/js/jquery-3.1.1.min.js"></script>
    <script src="/Public/js/jquery.validate-1.13.1.js"></script>
    <script src="/Public/js/checkform.js"></script>
    <script src="/Public/js/form.js"></script>
    <script src="/Public/js/bootstrap.min.js"></script>
    <script src="/Public/js/jquery.thooClock.js"></script>
</head>
<body>
<script>
    window.onload = function(){
        $('#myclock').thooClock();
    }
</script>
    <nav class="navbar navbar-inverse navbar-">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-collapse="collapse" data-target="#collapse">
                <span class="sr-only">toggle</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="javascript:;" class="navbar-brand">Brand</a>
        </div>
        <div class="collapse navbar-collapse" id="collapse">
            <ul class="nav navbar-nav">
                <li><a href="/Home/Index/index">首页</a></li>
                <li><a href="javascript:;">搜索</a></li>
                <li><a href="/Admin/Admin/admin">管理</a></li>
            </ul>
        </div>
    </div>
</nav>
    <div class="container">
        <div class="col-md-12 content">
            <div class="lContent col-md-8 col-sm-8">
                <form action="/Home/Index/createData" method="post" class="form-horizontal" id="signupForm">
    <div class="form-group">
        <label for="title" class="col-md-2 control-label"><strong class="require">*</strong>标题:</label>
        <div class="col-md-10">
            <input type="text" name="title" class="form-control" id="title" placeholder="请输入标题" >
        </div>
    </div>
    <div class="form-group">
        <label for="name" class="col-md-2 control-label"><strong class="require">*</strong>名称:</label>
        <div class="col-md-10">
            <input type="text" name="name" class="form-control" id="name" placeholder="请输入用户名" >
        </div>
    </div>
    <div class="form-group">
        <label for="qqnum" class="col-md-2 control-label"><strong class="require">*</strong>QQ:</label>
        <div class="col-md-10">
            <input type="text" name="qqnum" class="form-control" id="qqnum" placeholder="请输入QQ">
        </div>
    </div>
    <div class="form-group">
        <label for="content_text" class="col-md-2 control-label"><strong class="require">*</strong>内容:</label>
        <div class="col-md-10">
            <textarea name="content_text" class="form-control" id="content_text" rows="7">请输入内容</textarea>
        </div>
    </div>
    <div class="form-group">
        <label for="captcha" class="col-md-2 control-label"><strong class="require">*</strong>验证码:</label>
        <div class="col-md-8">
            <input type="text" name="captcha" id="captcha" class="form-control">
        </div>
        <div class="col-md-2">
            <a href="javascript:;" class="re_captcha"><img src="/Home/Index/showVerify" alt="验证码" class="img-responsive"></a>
            <label class="text-success success">验证码正确ヾ(Ő∀Ő๑)ﾉ太好惹</label>
            <label class="text-danger danger">验证码不正确ψ(╰_╯)</label>
        </div>
    </div>
    <div class="form-group">
        <div class="col-md-2 col-md-offset-10">
            <button class="btn btn-default submit" disabled>提交</button>
        </div>
    </div>
</form>
                <div class="article">
                    <?php if(is_array($data['data'])): foreach($data['data'] as $key=>$d): ?><label class="col-md-2"></label>
                        <div class="message text-left col-md-10 glowing disco">
                            <h4 class="text-center text-title"><?php echo ($d["title"]); ?></h4>
                            <p class="text">
                                <?php echo ($d["content"]); ?>
                            </p>
                            <span class="text-name">--<?php echo ($d["name"]); ?></span>
                        </div><?php endforeach; endif; ?>
                </div>
                <?php echo ($data['page']); ?>
            </div>
            <div class="rContent col-md-4 col-sm-4">
                <div class="info">
                    <h3 class="tips text-center">站点信息</h3>
                    <p class="label-info">当前有<strong><?php echo ($data['count']); ?></strong>条信息</p>
                    <div id="myclock"></div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>