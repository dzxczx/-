<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Title</title>
    <link rel="stylesheet" href="/Public/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Public/css/admin.css">
    <link rel="stylesheet" href="/Public/css/form.css">
    <script src="/Public/js/jquery-3.1.1.min.js"></script>
    <script src="/Public/js/jquery.validate-1.13.1.js"></script>
    <script src="/Public/js/admin.js"></script>
    <script src="/Public/js/form.js"></script>
    <script src="/Public/js/checkform.js"></script>
</head>
<body>
    <nav class="navbar navbar-inverse navbar-">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-collapse="collapse" data-target="#collapse">
                <span class="sr-only">toggle</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="javascript:;" class="navbar-brand">Brand</a>
        </div>
        <div class="collapse navbar-collapse" id="collapse">
            <ul class="nav navbar-nav">
                <li><a href="/Home/Index/index">首页</a></li>
                <li><a href="javascript:;">搜索</a></li>
                <li><a href="/Admin/Admin/admin">管理</a></li>
            </ul>
        </div>
    </div>
</nav>
    <div class="col-md-2 col-sm-2 col-xs-2 col-lg-2 pull-left sliderbar" style="background-color: lightgreen;">
        <ul class="list-unstyled text-center sliderbar-nav">
            <li class="active"><a href="#" class="home">首页</a></li>
            <li><a href="#" class="show">显示</a></li>
            <li><a href="#" class="create">发表</a></li>
            <li><a href="#" class="edit">编辑</a></li>
            <li><a href="#" class="delete">删除</a></li>
        </ul>
    </div>
    <div class="col-md-10 col-sm-10 col-xs-10 col-lg-10 pull-left content" style="background-color: lightblue;">
        <div class="col-md-12 home-content">
            <h1>欢迎<strong><?php echo ($name); ?></strong>进入后台管理页面</h1>
        </div>
        <div class="col-md-12 show-content">
            <table class="table table-bordered table-striped table-hover table-responsive">
                <thead>
                    <tr>
                        <th><input type="checkbox" name="is_all" value="all" id="all"></th>
                        <th>ID</th>
                        <th>姓名</th>
                        <th>标题</th>
                        <th>内容</th>
                        <th>功能</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(is_array($data['data'])): foreach($data['data'] as $key=>$d): ?><tr>
                            <td><input type="checkbox" name="id" value="1"></td>
                            <td><?php echo ($d["id"]); ?></td>
                            <td><?php echo ($d["name"]); ?></td>
                            <td><?php echo ($d["title"]); ?></td>
                            <td><?php echo ($d["content"]); ?></td>
                            <td colspan="2">
                                <div class="btn-group">
                                    <a href="#" class="btn btn-default">编辑</a>
                                    <a href="/Admin/Admin/deleteData/id/<?php echo ($d["id"]); ?>" class="btn btn-default">删除</a>
                                    <a href="#" class="btn btn-default">查看全文</a>
                                </div>
                            </td>
                        </tr><?php endforeach; endif; ?>
                </tbody>
            </table>
            <div class="btn-group pull-lef btn-all">
                <a href="#" class="btn btn-default edit-text">编辑</a>
                <a href="#" class="btn btn-default delete-text">删除</a>
                <a href="#" class="btn btn-default cat-text">查看全文</a>
            </div>
            <div class="btn-group pull-right">
                <?php echo ($data['page']); ?>
            </div>
        </div>
        <div class="col-md-12 create-content">
            <form action="/Admin/Admin/createData" method="post" class="form-horizontal" id="signupForm">
                <div class="form-group">
                    <label for="title" class="col-md-1 control-label"><strong class="require">*</strong>标题:</label>
                    <div class="col-md-11">
                        <input type="text" name="title" class="form-control" id="title" placeholder="请输入标题" >
                    </div>
                </div>
                <div class="form-group">
                    <label for="name" class="col-md-1 control-label"><strong class="require">*</strong>名称:</label>
                    <div class="col-md-11">
                        <input type="text" name="name" class="form-control" id="name" placeholder="请输入用户名" >
                    </div>
                </div>
                <div class="form-group">
                    <label for="qqnum" class="col-md-1 control-label"><strong class="require">*</strong>QQ:</label>
                    <div class="col-md-11">
                        <input type="text" name="qqnum" class="form-control" id="qqnum" placeholder="请输入QQ">
                    </div>
                </div>
                <div class="form-group">
                    <label for="content_text" class="col-md-1 control-label"><strong class="require">*</strong>内容:</label>
                    <div class="col-md-11">
                        <textarea name="content_text" class="form-control" id="content_text" rows="7">请输入内容</textarea>
                    </div>
                </div>
                <div class="form-group">
                    <label for="captcha" class="col-md-1 control-label"><strong class="require">*</strong>验证码:</label>
                    <div class="col-md-9">
                        <input type="text" name="captcha" id="captcha" class="form-control">
                    </div>
                    <div class="col-md-2">
                        <a href="javascript:;" class="re_captcha"><img src="/Home/Index/showVerify" alt="验证码" class="img-responsive"></a>
                        <label class="text-success success">验证码正确ヾ(Ő∀Ő๑)ﾉ太好惹</label>
                        <label class="text-danger danger">验证码不正确ψ(╰_╯)</label>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-2 col-md-offset-10">
                        <button class="btn btn-default submit" disabled>提交</button>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-md-12 edit-content">
            <form action="/Admin/Admin/updateData" method="post" class="form-horizontal">
                <div class="form-group">
                    <label class="col-md-1 control-label">id:</label>
                    <div class="col-md-11">
                        <input type="text" name="id" class="form-control" placeholder="请输入id" >
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-1 control-label">标题:</label>
                    <div class="col-md-11">
                        <input type="text" name="title" class="form-control" placeholder="请输入标题" >
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-1 control-label">姓名:</label>
                    <div class="col-md-11">
                        <input type="text" name="name" class="form-control" placeholder="请输入姓名" >
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-1 control-label">QQ:</label>
                    <div class="col-md-11">
                        <input type="text" name="qq_num" class="form-control" placeholder="请输入qq" >
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-1 control-label">内容:</label>
                    <div class="col-md-11">
                        <textarea name="content_text" class="form-control" rows="7">请输入内容</textarea>
                    </div>
                </div>
                <div class="form-group">
                    <label for="captcha" class="col-md-1 control-label"><strong class="require">*</strong>验证码:</label>
                    <div class="col-md-9">
                        <input type="text" name="captcha" class="form-control">
                    </div>
                    <div class="col-md-2">
                        <a href="javascript:;" class="re_captcha"><img src="/Home/Index/showVerify" alt="验证码" class="img-responsive"></a>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-2 col-md-offset-10">
                        <button class="btn btn-default submit">提交</button>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-md-12 delete-content">
            <form action="/Admin/Admin/deleteData" method="post" class="form-horizontal">
                <div class="form-group">
                    <label class="col-md-1 control-label">id:</label>
                    <div class="col-md-11">
                        <input type="text" name="id" class="form-control" placeholder="请输入id" >
                    </div>
                </div>
                <div class="form-group">
                    <label for="captcha" class="col-md-1 control-label"><strong class="require">*</strong>验证码:</label>
                    <div class="col-md-9">
                        <input type="text" name="captcha" class="form-control">
                    </div>
                    <div class="col-md-2">
                        <a href="javascript:;" class="re_captcha"><img src="/Home/Index/showVerify" alt="验证码" class="img-responsive"></a>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-2 col-md-offset-10">
                        <button class="btn btn-default submit">提交</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</body>
</html>