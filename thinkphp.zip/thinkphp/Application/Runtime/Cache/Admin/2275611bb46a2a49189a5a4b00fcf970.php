<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="/Public/css/bootstrap.min.css">
    <script src="/Public/js/jquery-3.1.1.min.js"></script>
    <script src="/Public/js/jquery.validate-1.13.1.js"></script>
    <script src="/Public/js/login.js"></script>
</head>
<body>
<div class="container">
    <form action="/Admin/Admin/login_check" method="post" class="form-horizontal" id="loginForm">
        <div class="form-group">
            <label for="username" class="control-label col-md-2">用户名:</label>
            <div class="col-md-10">
                <input type="text" name="username" class="form-control" id="username" placeholder="请输入用户名">
            </div>
        </div>
        <div class="form-group">
            <label for="password" class="control-label col-md-2">密码:</label>
            <div class="col-md-10">
                <input type="password" name="password" class="form-control" id="password" placeholder="请输入密码">
            </div>
        </div>
        <div class="form-group">
            <label for="captcha" class="control-label col-md-2">验证码:</label>
            <div class="col-md-9">
                <input type="text" name="captcha" id="captcha"  class="form-control" placeholder="请输入验证码">
            </div>
            <div class="col-md-1">
                <a href="javascript:;" class="re_captcha">
                    <img src="/Admin/Admin/showVerify" alt="" class="img-responsive" style="height:34px;">
                </a>
            </div>
        </div>
        <div class="form-group">
            <div class="col-md-10 col-md-offset-2">
                <button class="btn btn-default submit">登录</button>
            </div>
        </div>
    </form>
</div>
</body>
</html>