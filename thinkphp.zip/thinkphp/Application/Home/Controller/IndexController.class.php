<?php
namespace Home\Controller;
use Think\Controller;

class IndexController extends Controller {
    public function index() {
        $this->pageData();
        $this->display('index');
    }

    public function createData() {
        $manager = A('Common/Manager');
        if ($manager->createData()) {
            $this->success('发表成功!', '/Home/Index');
        } else {
            $this->error('发表失败!', '/Home/Index');
        }
    }

    public function showVerify() {
        $manager = A('Common/Manager');
        $manager->showVerify(1);
    }

    public function checkVerify() {
        $manager = A('Common/Manager');
        if (IS_AJAX) {
            $code = I('post.code', '');
            $data = array();
            if ($manager->checkVerify($code,1)) {
                $data['status'] = 1;
                $this->ajaxReturn($data);
            } else {
                $data['status'] = 2;
                $this->ajaxReturn($data);
            }
        }
    }

    private function pageData() {
        $manager = A('Common/Manager');
        $data = $manager->pageData(1);
        $this->assign('data', $data);
    }
}